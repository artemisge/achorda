package com.itsme;

public class Progression {
    void generateProgression(){};
}
