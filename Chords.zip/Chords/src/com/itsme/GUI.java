package com.itsme;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.scene.control.*;

import java.io.File;
import java.io.IOException;

public class GUI extends Application {
    TextArea text;
    Song song;

    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("Chordshit");

        //Song song = new Song("HouseOfTheRisingSun");
//        Song song = new Song("Test");
//
//        text = new TextArea(song.printSong());
//        StackPane layout = new StackPane();
//        //ebgaze error me to text epeidi den itan apo to javafx control alla apo to atw
//        layout.getChildren().add(text);

       // Scene scene = new Scene(layout, 800, 600);
        //stage.setScene(scene);
        songPanel();
        stage.show();
    }

    public void songPanel() {

    }
}
