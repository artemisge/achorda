package com.itsme;

public enum notes {
    a, as, b, c, cs, d, ds, e, f, fs, g, gs
}
