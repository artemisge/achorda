package com.itsme;

public enum chordType {
    MAJOR,
    MINOR,
    MAJORSEVEN,
    MINORSEVEN,
    NINE,
    DIMINISHED,

}
