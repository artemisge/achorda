package com.itsme;

public class Chord {
    public int scaleNote; //i bathmida px I, IV, xoris na mas noiazei minor/major
    public String guiChord; //px Am, Bdim, G7
    public chordType attribute; //to chord type px major, minor

    public Chord(int scaleNote, chordType attribute) {
        this.scaleNote = scaleNote;
        this.attribute = attribute;
    }

    public void print() {
        System.out.println(scaleNote + " "+ attribute.toString() +"\n");
    }
}
