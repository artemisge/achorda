package com.itsme;

public class BaseSongClass {
    String name;
    public static final String[] notes = {"a", "a#", "b", "c", "c#", "d", "d#", "e", "f", "f#", "g", "g#"};
    String[] chords;
    int originalkey;
    int currentkey;

    public BaseSongClass(){
        //load from file the song
    }
    void save(){};
    void load(){};

}
